// script.js - nav/hamburger, filters, fee calc, contact validation

document.addEventListener('DOMContentLoaded', () => {
    // Mobile drawer
    const openDrawerBtn = document.querySelectorAll('.js-open-drawer');
    const drawer = document.getElementById('mobile-drawer');
    const closeDrawer = document.getElementById('mobile-drawer-close');
    openDrawerBtn.forEach(b => b && b.addEventListener('click', (e) => {
      e.preventDefault(); drawer.classList.add('open');
    }));
    closeDrawer && closeDrawer.addEventListener('click', ()=> drawer.classList.remove('open'));
    drawer && drawer.addEventListener('click', e => { if(e.target === drawer) drawer.classList.remove('open') });
  
    // Filters on courses page
    const filterButtons = document.querySelectorAll('[data-filter]');
    if(filterButtons.length){
      filterButtons.forEach(btn=>{
        btn.addEventListener('click', ()=>{
          const filter = btn.getAttribute('data-filter');
          document.querySelectorAll('.course-card').forEach(card=>{
            if(filter === 'all' || card.dataset.type === filter) card.style.display = '';
            else card.style.display = 'none';
          });
          filterButtons.forEach(b=>b.classList.remove('active'));
          btn.classList.add('active');
        });
      });
    }
  
    // Fee calculator (works on pages where .calc exists)
    function calcFees(container){
      if(!container) return;
      const select = container.querySelector('select[data-course]');
      const chk = container.querySelector('input[data-materials]');
      const scholarship = container.querySelector('input[data-scholarship]');
      const output = container.querySelector('[data-total]');
      function update(){
        const slug = select.value;
        // course data map
        const data = {
          'first-aid':1800,'sewing':7800,'life-skills':1500,'landscaping':8400,
          'child-minding':2000,'garden-maintenance':7200,'cooking':2400
        };
        const base = data[slug] || 0;
        const mat = chk.checked ? (slug.includes('sewing')||slug.includes('landscaping') ? 1200 : 450) : 0;
        let disc = Number(scholarship.value||0); if(isNaN(disc)) disc = 0;
        disc = Math.max(0, Math.min(40, disc)); // clamp
        const gross = base + mat;
        const net = Math.round(gross * (1 - disc/100));
        output.textContent = new Intl.NumberFormat('en-ZA',{style:'currency',currency:'ZAR'}).format(net);
      }
      select && select.addEventListener('change', update);
      chk && chk.addEventListener('change', update);
      scholarship && scholarship.addEventListener('input', update);
      update();
    }
    document.querySelectorAll('.calc').forEach(calcFees);
  
    // Contact form validation
    const contactForm = document.getElementById('contact-form');
    if(contactForm){
      contactForm.addEventListener('submit', function(e){
        e.preventDefault();
        const name = this.querySelector('[name="name"]');
        const email = this.querySelector('[name="email"]');
        const message = this.querySelector('[name="message"]');
        let ok = true;
        function setErr(el,msg){el.classList.add('error'); const em = el.parentElement.querySelector('.err-msg'); if(em) em.textContent = msg; ok=false;}
        function clearErr(el){el.classList.remove('error'); const em = el.parentElement.querySelector('.err-msg'); if(em) em.textContent = '';}
        // simple checks
        if(!name.value.trim()) setErr(name,'Name is required'); else clearErr(name);
        if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value)) setErr(email,'Valid email required'); else clearErr(email);
        if(message.value.trim().length < 10) setErr(message,'Message must be at least 10 characters'); else clearErr(message);
        if(!ok) return;
        // simulate send
        alert('Message sent — opening your mail client for final send.');
        const subj = encodeURIComponent('Course enquiry');
        const body = encodeURIComponent(`${message.value}\n\n— ${name.value} (${email.value})`);
        window.location.href = `mailto:info@empowering.example?subject=${subj}&body=${body}`;
      });
    }
  
    // Back buttons
    document.querySelectorAll('.js-back').forEach(b => b.addEventListener('click', (e)=>{ e.preventDefault(); history.back(); }));
  });
  